/* ==========================================================================
   SIMULAÇÃO 3D — PONTE LEVADIÇA AUTOMATIZADA
   Three.js (r128), execução 100% local no navegador.
   Parâmetros de tempo espelham o firmware ponte_levadica.ino (Seção 24 do
   relatório: "Relação entre simulação e protótipo físico").
   ========================================================================== */

// ---------------------------------------------------------------------------
// PARÂMETROS (equivalentes às constantes do firmware)
// ---------------------------------------------------------------------------
const TEMPO_PONTE_ABERTA_S   = 30;      // igual a TEMPO_PONTE_ABERTA_MS do .ino
const DISTANCIA_DETECCAO_CM  = 30;      // igual a DISTANCIA_DETECCAO_CM do .ino
const DURACAO_MOVIMENTO_S    = 2.4;     // ~ tempo calculado na Seção 7.5 do relatório
const ALTURA_MAX_PONTE       = 2.2;     // unidades de cena (elevação vertical)

// ---------------------------------------------------------------------------
// ESTADO DA MÁQUINA (mesmos nomes do firmware)
// ---------------------------------------------------------------------------
const Estados = {
  IDLE: "IDLE", DETECTING: "DETECTING", OPENING: "OPENING",
  OPEN: "OPEN", CLOSING: "CLOSING", ERROR: "ERROR"
};

let estado = Estados.IDLE;
let autoModo = false;
let posicaoPonte = 0;          // 0 = fechada, 1 = totalmente aberta
let movimentoTempoAcumulado = 0;
let cronometroAberto = 0;
let distanciaSimulada = 400;   // cm
let barcoAtivo = false;
let barcoZ = 40;               // posição do barco no eixo de navegação

// ---------------------------------------------------------------------------
// SETUP THREE.JS
// ---------------------------------------------------------------------------
const viewportEl = document.getElementById("viewport");
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b1f33);
scene.fog = new THREE.Fog(0x0b1f33, 30, 90);

const camera = new THREE.PerspectiveCamera(45, viewportEl.clientWidth / viewportEl.clientHeight, 0.1, 200);
camera.position.set(14, 9, 16);
camera.lookAt(0, 2, 0);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(viewportEl.clientWidth, viewportEl.clientHeight);
viewportEl.appendChild(renderer.domElement);

// Luzes
scene.add(new THREE.AmbientLight(0xffffff, 0.55));
const dirLight = new THREE.DirectionalLight(0xfff2d0, 0.9);
dirLight.position.set(10, 18, 8);
scene.add(dirLight);

// "Água" (canal de navegação)
const agua = new THREE.Mesh(
  new THREE.PlaneGeometry(60, 14),
  new THREE.MeshStandardMaterial({ color: 0x123449, roughness: 0.8 })
);
agua.rotation.x = -Math.PI / 2;
agua.position.set(0, -0.05, 0);
scene.add(agua);

// Materiais (paleta navy/gold do projeto)
const matAluminio = new THREE.MeshStandardMaterial({ color: 0xb9c3cc, metalness: 0.6, roughness: 0.35 });
const matZinco   = new THREE.MeshStandardMaterial({ color: 0x8b97a1, metalness: 0.4, roughness: 0.5 });
const matGold    = new THREE.MeshStandardMaterial({ color: 0xc9a24b, metalness: 0.5, roughness: 0.3 });
const matCabo    = new THREE.LineBasicMaterial({ color: 0xd8d8d8 });
const matBarco   = new THREE.MeshStandardMaterial({ color: 0x6f5233, roughness: 0.7 });

// ---------------------------------------------------------------------------
// TORRES (perfil de alumínio)
// ---------------------------------------------------------------------------
function criarTorre(x) {
  const grupo = new THREE.Group();
  const perfil = new THREE.Mesh(new THREE.BoxGeometry(0.4, 5, 0.4), matAluminio);
  perfil.position.set(x, 2.5, -2.4);
  grupo.add(perfil);
  const perfil2 = new THREE.Mesh(new THREE.BoxGeometry(0.4, 5, 0.4), matAluminio);
  perfil2.position.set(x, 2.5, 2.4);
  grupo.add(perfil2);
  const travessa = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.3, 5), matAluminio);
  travessa.position.set(x, 5, 0);
  grupo.add(travessa);
  scene.add(grupo);
  return grupo;
}
criarTorre(-4);
criarTorre(4);

// Polias (topo das torres)
function criarPolia(x) {
  const polia = new THREE.Mesh(new THREE.TorusGeometry(0.35, 0.08, 8, 20), matGold);
  polia.rotation.y = Math.PI / 2;
  polia.position.set(x, 4.9, 0);
  scene.add(polia);
  return polia;
}
const poliaEsq = criarPolia(-4);
const poliaDir = criarPolia(4);

// Tambores + suporte do motor (base)
function criarTamborEMotor(x) {
  const grupo = new THREE.Group();
  const tambor = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.6, 16), matGold);
  tambor.rotation.z = Math.PI / 2;
  tambor.position.set(x, 0.6, 0);
  grupo.add(tambor);

  const motorCorpo = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 0.5), new THREE.MeshStandardMaterial({ color: 0x24303c }));
  motorCorpo.position.set(x, 0.6, 0.6);
  grupo.add(motorCorpo);

  scene.add(grupo);
  return { grupo, tambor };
}
const tamborEsq = criarTamborEMotor(-4);
const tamborDir = criarTamborEMotor(4);

// ---------------------------------------------------------------------------
// TABULEIRO DA PONTE (chapa de zinco)
// ---------------------------------------------------------------------------
const tabuleiro = new THREE.Mesh(new THREE.BoxGeometry(7.4, 0.25, 3.6), matZinco);
tabuleiro.position.set(0, 0.6, 0);
scene.add(tabuleiro);

// Guias laterais (representação simples)
[-3.5, 3.5].forEach((x) => {
  const guia = new THREE.Mesh(new THREE.BoxGeometry(0.15, 5, 0.15), matAluminio);
  guia.position.set(x, 2.5, 0);
  scene.add(guia);
});

// ---------------------------------------------------------------------------
// CABOS DE AÇO (linhas dinâmicas entre polia e tabuleiro)
// ---------------------------------------------------------------------------
function criarCabo() {
  const geometry = new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(0, 0, 0),
    new THREE.Vector3(0, 0, 0),
  ]);
  const linha = new THREE.Line(geometry, matCabo);
  scene.add(linha);
  return linha;
}
const caboEsq = criarCabo();
const caboDir = criarCabo();

function atualizarCabo(linha, poliaObj, xTab) {
  const pontoPolia = new THREE.Vector3(poliaObj.position.x, poliaObj.position.y, 0);
  const pontoTabuleiro = new THREE.Vector3(xTab, tabuleiro.position.y, 0);
  linha.geometry.setFromPoints([pontoPolia, pontoTabuleiro]);
}

// ---------------------------------------------------------------------------
// EMBARCAÇÃO (cubo simplificado)
// ---------------------------------------------------------------------------
const barco = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.6, 0.9), matBarco);
barco.position.set(0, 0.3, barcoZ);
barco.visible = false;
scene.add(barco);

// Sensor (representação no topo de uma torre)
const sensorMesh = new THREE.Mesh(new THREE.SphereGeometry(0.15, 10, 10), new THREE.MeshStandardMaterial({ color: 0x4caf7d, emissive: 0x113322 }));
sensorMesh.position.set(0, 5.1, -2.3);
scene.add(sensorMesh);

// ---------------------------------------------------------------------------
// LOOP DE RENDER + ANIMAÇÃO MECÂNICA
// ---------------------------------------------------------------------------
const clock = new THREE.Clock();

function aplicarPosicaoPonte(p) {
  // p = 0..1
  const altura = 0.6 + p * ALTURA_MAX_PONTE;
  tabuleiro.position.y = altura;

  // Rotação leve do tabuleiro conforme sobe (efeito bascule sutil opcional)
  tabuleiro.rotation.z = 0;

  atualizarCabo(caboEsq, poliaEsq, -3.5);
  atualizarCabo(caboDir, poliaDir, 3.5);
}

function girarTambores(delta, sentido) {
  const vel = sentido * (Math.PI * 2) * (1 / DURACAO_MOVIMENTO_S);
  tamborEsq.tambor.rotation.x += vel * delta;
  tamborDir.tambor.rotation.x += vel * delta;
}

function animar() {
  requestAnimationFrame(animar);
  const delta = clock.getDelta();

  atualizarLogica(delta);
  aplicarPosicaoPonte(posicaoPonte);

  if (estado === Estados.OPENING) girarTambores(delta, 1);
  if (estado === Estados.CLOSING) girarTambores(delta, -1);

  // Movimento do barco quando ativo
  if (barcoAtivo) {
    barco.visible = true;
    barcoZ -= delta * 4;
    barco.position.z = barcoZ;
    distanciaSimulada = Math.max(0, Math.round((barcoZ + 10) * 8));
    if (barcoZ < -40) {
      barcoAtivo = false;
      barco.visible = false;
      barcoZ = 40;
      distanciaSimulada = 400;
    }
  }

  sensorMesh.material.color.set(distanciaSimulada < DISTANCIA_DETECCAO_CM ? 0xd9534f : 0x4caf7d);

  renderer.render(scene, camera);
  atualizarHUD();
}
animar();

// ---------------------------------------------------------------------------
// LÓGICA DE ESTADOS (espelha o firmware: IDLE -> DETECTING -> OPENING ->
// OPEN (30s, com retenção se area ocupada) -> CLOSING -> IDLE)
// ---------------------------------------------------------------------------
function atualizarLogica(delta) {
  switch (estado) {
    case Estados.IDLE:
      if (autoModo && distanciaSimulada < DISTANCIA_DETECCAO_CM) {
        estado = Estados.DETECTING;
      }
      break;

    case Estados.DETECTING:
      // debounce simplificado: confirma na próxima leitura
      if (distanciaSimulada < DISTANCIA_DETECCAO_CM) {
        estado = Estados.OPENING;
        movimentoTempoAcumulado = 0;
      } else {
        estado = Estados.IDLE;
      }
      break;

    case Estados.OPENING:
      movimentoTempoAcumulado += delta;
      posicaoPonte = Math.min(1, movimentoTempoAcumulado / DURACAO_MOVIMENTO_S);
      if (posicaoPonte >= 1) {
        estado = Estados.OPEN;
        cronometroAberto = 0;
      }
      break;

    case Estados.OPEN:
      cronometroAberto += delta;
      if (cronometroAberto >= TEMPO_PONTE_ABERTA_S) {
        if (distanciaSimulada >= DISTANCIA_DETECCAO_CM) {
          estado = Estados.CLOSING;
          movimentoTempoAcumulado = 0;
        }
        // se área ocupada, permanece em OPEN (retenção, igual ao firmware)
      }
      break;

    case Estados.CLOSING:
      movimentoTempoAcumulado += delta;
      posicaoPonte = Math.max(0, 1 - movimentoTempoAcumulado / DURACAO_MOVIMENTO_S);
      if (posicaoPonte <= 0) {
        estado = Estados.IDLE;
      }
      break;
  }
}

// ---------------------------------------------------------------------------
// HUD
// ---------------------------------------------------------------------------
const hudEstado = document.getElementById("hud-estado");
const hudDistancia = document.getElementById("hud-distancia");
const hudPosicao = document.getElementById("hud-posicao");
const hudVelocidade = document.getElementById("hud-velocidade");
const hudTimer = document.getElementById("hud-timer");
const hudMotores = document.getElementById("hud-motores");

function atualizarHUD() {
  hudEstado.textContent = estado;
  hudDistancia.textContent = `${distanciaSimulada} cm`;
  hudPosicao.textContent = `${Math.round(posicaoPonte * 100)}%`;
  hudVelocidade.textContent = (estado === Estados.OPENING || estado === Estados.CLOSING) ? "em movimento" : "parado";

  if (estado === Estados.OPEN) {
    const restante = Math.max(0, TEMPO_PONTE_ABERTA_S - cronometroAberto);
    hudTimer.textContent = `${restante.toFixed(1)}s`;
  } else {
    hudTimer.textContent = "--";
  }

  const statusMotor = estado === Estados.OPENING ? "subindo" : estado === Estados.CLOSING ? "descendo" : "parado";
  hudMotores.textContent = `${statusMotor} / ${statusMotor}`;
}

// ---------------------------------------------------------------------------
// CONTROLES (botões)
// ---------------------------------------------------------------------------
document.getElementById("btn-auto").addEventListener("click", () => {
  autoModo = true;
});
document.getElementById("btn-parar").addEventListener("click", () => {
  autoModo = false;
});
document.getElementById("btn-reset").addEventListener("click", () => {
  estado = Estados.IDLE;
  posicaoPonte = 0;
  cronometroAberto = 0;
  movimentoTempoAcumulado = 0;
  barcoAtivo = false;
  barco.visible = false;
  barcoZ = 40;
  distanciaSimulada = 400;
  autoModo = false;
});
document.getElementById("btn-abrir").addEventListener("click", () => {
  if (estado === Estados.IDLE || estado === Estados.DETECTING) {
    estado = Estados.OPENING;
    movimentoTempoAcumulado = 0;
  }
});
document.getElementById("btn-fechar").addEventListener("click", () => {
  if (estado === Estados.OPEN) {
    estado = Estados.CLOSING;
    movimentoTempoAcumulado = 0;
  }
});
document.getElementById("btn-embarcacao").addEventListener("click", () => {
  barcoAtivo = true;
  barcoZ = 40;
  barco.visible = true;
});

// ---------------------------------------------------------------------------
// RESIZE
// ---------------------------------------------------------------------------
window.addEventListener("resize", () => {
  camera.aspect = viewportEl.clientWidth / viewportEl.clientHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(viewportEl.clientWidth, viewportEl.clientHeight);
});
